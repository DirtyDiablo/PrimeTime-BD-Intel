# GBSD Orchestrator (n8n + OpenAI + Airtable + Apify)

## Files
- `.env.example` — copy to `.env` and fill in your keys
- `docker-compose.yml` — run n8n locally
- `n8n_gbsd_orchestrator.json` — importable workflow

## Quickstart
1. Copy `.env.example` to `.env` and fill values.
2. Run `docker compose up -d`.
3. Open http://localhost:5678
4. Create credentials:
   - Airtable API (token)
   - HTTP creds named `openai-creds` (blank user/pass; the node uses Bearer header with your env var)
5. Import `n8n_gbsd_orchestrator.json`.
6. Execute once; confirm rows in Airtable and summary output.
